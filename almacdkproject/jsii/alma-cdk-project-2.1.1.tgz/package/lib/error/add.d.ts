import { Construct } from "constructs";
export declare function addError(scope: Construct, message: string): void;
