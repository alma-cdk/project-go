export interface NameProps {
    override?: string;
    stackId: string;
    projectName: string;
    accountType?: string;
    environmentType?: string;
}
export declare function formatName(props: NameProps): string;
