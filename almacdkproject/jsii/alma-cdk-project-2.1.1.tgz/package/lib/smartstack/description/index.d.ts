export interface DescriptionProps {
    body: string;
    accountType?: string;
    environmentType?: string;
}
export declare function formatDescription(props: DescriptionProps): string;
