import { Stack, StackProps } from "aws-cdk-lib";
import { Construct } from "constructs";
export declare class SmartStack extends Stack {
    private readonly descriptionMinLength;
    private readonly descriptionMaxLength;
    constructor(scope: Construct, id: string, props: StackProps);
    private validateDescriptionMinLength;
    private validateDescriptionMaxLength;
}
