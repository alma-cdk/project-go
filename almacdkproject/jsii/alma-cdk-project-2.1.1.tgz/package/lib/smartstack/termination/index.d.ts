export interface TerminationProtectionProps {
    override?: boolean;
    environmentType?: string;
}
export declare function decideTerminationProtection(props: TerminationProtectionProps): boolean;
