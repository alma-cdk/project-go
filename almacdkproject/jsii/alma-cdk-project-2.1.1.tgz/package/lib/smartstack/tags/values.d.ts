import { Construct } from "constructs";
export interface Values {
    accountType?: string;
    environmentType?: string;
    projectName: string;
    authorName: string;
    authorOrganization?: string;
    authorEmail?: string;
}
export declare enum tagKey {
    NAME = "Name",
    ACCOUNT = "Account",
    ENVIRONMENT = "Environment",
    LEGACY_PROJECT_ENVIRONMENT = "ProjectAndEnvironment",
    PROJECT = "Project",
    AUTHOR_NAME = "Author",
    AUTHOR_ORGANIZATION = "Organization",
    AUTHOR_EMAIL = "Contact"
}
export declare function resolveTagValues(scope: Construct): Values;
