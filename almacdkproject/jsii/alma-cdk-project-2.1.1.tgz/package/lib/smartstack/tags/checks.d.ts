import { Values } from "./values";
export declare function hasAccount(values: Values): boolean;
export declare function hasEnvironment(values: Values): boolean;
