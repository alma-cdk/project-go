import { Tags } from "aws-cdk-lib";
export declare function excludeSpecials(tags: Tags): void;
