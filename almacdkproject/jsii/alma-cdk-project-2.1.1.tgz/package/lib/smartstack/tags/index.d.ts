import { Construct } from "constructs";
export declare function addTags(scope: Construct): void;
