import { Tags } from "aws-cdk-lib";
import { Construct } from "constructs";
import { Values } from "./values";
interface Tagger {
    (scope: Construct, tags: Tags, values: Values): void;
}
export declare const tagAccount: Tagger;
export declare const tagEnvironment: Tagger;
export declare const tagProject: Tagger;
export declare const tagAuthorName: Tagger;
export declare const tagAuthorOrganization: Tagger;
export declare const tagAuthorEmail: Tagger;
export {};
