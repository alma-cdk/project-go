import { Construct } from "constructs";
/**
 * Wrapper for account-level stacks.
 */
export declare class AccountWrapper extends Construct {
    constructor(scope: Construct);
}
