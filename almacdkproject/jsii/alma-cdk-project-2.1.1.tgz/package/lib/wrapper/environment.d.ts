import { Construct } from "constructs";
/**
 * Wrapper for environmental stacks.
 */
export declare class EnvironmentWrapper extends Construct {
    constructor(scope: Construct);
}
