import * as cdk from "aws-cdk-lib";
import { Project, SmartStack, Account, AccountType } from "..";
interface TestStackInSharedAccountProps {
    defaultRegion?: string;
    accounts: Record<string, Account>;
    accountType: AccountType;
    environmentType?: string;
    stackProps?: cdk.StackProps;
    appContext?: Record<string, any>;
}
export declare class TestableProjectStack extends SmartStack {
    readonly project: Project;
    readonly projectName: string;
    readonly stackConstructId: string;
    constructor(props: TestStackInSharedAccountProps);
}
export {};
