import { Construct } from "constructs";
export declare function expectErrorMetadata(scope: Construct, matcher?: jest.Expect): void;
