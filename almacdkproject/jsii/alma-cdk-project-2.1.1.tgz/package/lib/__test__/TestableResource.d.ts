import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
interface TestableResourceProps {
    id?: string;
    scope?: Construct;
    context?: Record<string, unknown>;
}
/**
 * A helper class that allows easier testing.
 */
export declare class TestableResource extends cdk.Resource implements cdk.ITaggable {
    static readonly TYPE = "For::Testing";
    readonly tags: cdk.TagManager;
    constructor(props?: TestableResourceProps);
    hasProperties(props: Record<string, unknown>): void;
}
export {};
