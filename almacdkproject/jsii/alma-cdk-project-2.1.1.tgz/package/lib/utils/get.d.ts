export declare function get(obj: Record<string, any> | undefined, path: string, defValue?: any): any;
