import { Account } from "../project";
export declare function findAccountTypeByEnvironment(obj: Record<string, Account>, predicate: string): string | undefined;
