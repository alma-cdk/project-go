type TemplateContextValue = string | undefined;
export type TemplateContext = Record<string, TemplateContextValue>;
export declare function renderTemplate<T extends TemplateContext>(template: string, context: T): string;
export {};
