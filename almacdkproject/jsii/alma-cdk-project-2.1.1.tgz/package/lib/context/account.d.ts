import { Construct } from "constructs";
export declare class AccountContext {
    static getAccountId(scope: Construct): string;
    static getAccountConfig(scope: Construct, key: string): any;
    static getAccountType(scope: Construct): string;
    static isMock(scope: Construct): boolean;
    static isShared(scope: Construct): boolean;
    static isDev(scope: Construct): boolean;
    static isPreProd(scope: Construct): boolean;
    static isProd(scope: Construct): boolean;
    private static isAccountTypeMatch;
}
