import { Construct } from "constructs";
import { NameProps } from "./interfaces";
import { Name } from "./name";
export declare abstract class UrlName extends Name {
    static it(scope: Construct, baseName: string, props?: NameProps): string;
    static withProject(scope: Construct, baseName: string, props?: NameProps): string;
    static globally(scope: Construct, baseName: string, props?: NameProps): string;
}
