import { Construct } from "constructs";
export declare const MAX_LENGTH_DEFAULT = 63;
export declare const MAX_LENGTH_PATH = 900;
export declare function decideMaxLength(value: string, maxLengthProp?: number): number;
export declare function isTooLong(value: string, maxLength?: number): boolean;
export declare function validateMaxLength(scope: Construct, value: string, maxLength?: number): void;
