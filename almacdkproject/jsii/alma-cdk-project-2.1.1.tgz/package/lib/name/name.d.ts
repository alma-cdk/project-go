import { Construct } from "constructs";
import { NameProps } from "./interfaces";
export declare abstract class Name {
    static it(scope: Construct, baseName: string, props?: NameProps): string;
    static withProject(scope: Construct, baseName: string, props?: NameProps): string;
    /**
     * PascalCase naming with global prefixes (org, project…).
     */
    static globally(scope: Construct, baseName: string, props?: NameProps): string;
    private static nameIt;
    private static getContextualInformation;
    private static stripNonAlphanumeric;
}
