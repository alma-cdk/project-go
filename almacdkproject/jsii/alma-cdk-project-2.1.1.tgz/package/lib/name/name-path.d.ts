import { Construct } from "constructs";
import { NameProps } from "./interfaces";
import { UrlName } from "./name-url";
export declare abstract class PathName extends UrlName {
    static it(scope: Construct, baseName: string, props?: NameProps): string;
    static withProject(scope: Construct, baseName: string, props?: NameProps): string;
    static globally(scope: Construct, baseName: string, props?: NameProps): string;
}
