import { NameProps } from "./interfaces";
export declare function generateNewValue(value: string, baseName: string, props?: NameProps): string;
export declare function trim(value: string, baseName: string, props?: NameProps): string;
