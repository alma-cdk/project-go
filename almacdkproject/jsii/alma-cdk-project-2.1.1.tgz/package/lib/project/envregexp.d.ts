export declare class EnvRegExp {
    private regexp;
    constructor(base: string);
    test(value: string): boolean;
}
