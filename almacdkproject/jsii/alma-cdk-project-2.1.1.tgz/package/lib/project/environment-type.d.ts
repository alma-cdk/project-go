import { Construct } from "constructs";
/**
 * Internal class to handle set/get operations for Environment Type
 */
export declare class EnvironmentType {
    static set(scope: Construct, environmentType: string): void;
    static tryGet(scope: Construct): string | undefined;
    static get(scope: Construct, allowedEnvironments: string[]): string;
}
