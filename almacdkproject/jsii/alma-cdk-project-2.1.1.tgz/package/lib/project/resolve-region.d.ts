export declare function ensureRegionString(value: string | undefined): boolean;
export declare function resolveDefaultRegion(regionProp?: string): string;
