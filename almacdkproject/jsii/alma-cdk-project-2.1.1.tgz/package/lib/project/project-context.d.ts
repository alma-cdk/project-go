import { Construct } from "constructs";
export declare class ProjectContext {
    /**
     * Returns the account type given in runtime/CLI context
     */
    static getAccountType(scope: Construct): string;
    static getAccountId(scope: Construct): string;
    static getAccountConfig(scope: Construct, key: string, defaultValue?: any): any;
    static getDefaultRegion(scope: Construct): string;
    static getName(scope: Construct): string;
    static getAuthorOrganization(scope: Construct): string | undefined;
    static getAuthorName(scope: Construct): string;
    static getAuthorEmail(scope: Construct): string | undefined;
    static getAllowedEnvironments(scope: Construct): string[];
    static tryGetEnvironment(scope: Construct): string | undefined;
    static getEnvironment(scope: Construct): string;
    /**
     * Low-level / internal method which in most cases you should not use or depend upon.
     *
     * TODO Figure out
     *
     * @internal
     */
    static _getAccountTypeByEnvironment(scope: Construct, environmentType: string): string;
    /**
     * Returns the account specific project configuration
     */
    private static getProjectAccountConfiguration;
}
