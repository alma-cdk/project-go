import { Construct } from "constructs";
import { Account } from "./interfaces";
/**
 * Internal class to handle set/get operations for Account Type
 */
export declare class AccountType {
    static set(scope: Construct, accountType: string): void;
    static get(scope: Construct): string;
    static matchFromEnvironment(scope: Construct, accounts: Record<string, Account>, environmentType: string): string;
}
