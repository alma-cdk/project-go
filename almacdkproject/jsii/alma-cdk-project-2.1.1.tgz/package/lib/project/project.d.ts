import { App, AppProps } from "aws-cdk-lib";
import { Construct } from "constructs";
import { Account, ProjectConfiguration } from "./interfaces";
/**
 * Interface for acknowledging warnings.
 */
export interface Acknowledgeable {
    readonly id: string;
    readonly message?: string;
}
/** Props given to `Project`.
 *
 * I.e. custom props for this construct and the usual props given to `cdk.App`.
 * */
export interface ProjectProps extends ProjectConfiguration, AppProps {
}
/** High-level wrapper for `cdk.App` with specific requirements for props.
 *
 * Use it like you would `cdk.App` and assign stacks into it.
 *
 * @example
 * // new Project instead of new App
 * const project = new Project({
 *   name: 'my-cool-project',
 *   author: {
 *     organization: 'Acme Corp',
 *     name: 'Mad Scientists',
 *     email: 'mad.scientists@acme.example.com',
 *   },
 *   defaultRegion: 'eu-west-1', // defaults to one of: $CDK_DEFAULT_REGION, $AWS_REGION or us-east-1
 *   accounts: {
 *     dev: {
 *       id: '111111111111',
 *       environments: ['development', 'feature/.*', 'staging'],
 *       config: {
 *         baseDomain: 'example.net',
 *       },
 *     },
 *     prod: {
 *       id: '222222222222',
 *       environments: ['production'],
 *       config: {
 *         baseDomain: 'example.com',
 *       },
 *     },
 *   },
 * })
 */
export declare class Project extends App {
    /** Namespace/key how this tool internally keeps track of the project configuration */
    static readonly CONTEXT_SCOPE = "@alma-cdk/project@v1";
    /** Return the project configuration as given in ProjectProps */
    static getConfiguration(scope: Construct): ProjectConfiguration;
    /** Return account configuration */
    static getAccount(scope: Construct, accountType: string): Account;
    /** Initializes a new Project (which can be used in place of cdk.App) */
    constructor(props: ProjectProps);
    /**
     * Acknowledge warnings for all stacks in the project.
     */
    acknowledgeWarnings(acknowledgements: Acknowledgeable[]): void;
}
