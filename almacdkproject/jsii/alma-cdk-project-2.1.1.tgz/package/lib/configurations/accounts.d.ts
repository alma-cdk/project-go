import { Account } from "../project";
/**
 * Enumeration of all account types.
 */
export declare enum AccountType {
    MOCK = "mock",
    SHARED = "shared",
    DEV = "dev",
    PREPROD = "preprod",
    PROD = "prod"
}
/** Interface for a single account type configuration. */
export interface AccountConfiguration {
    readonly id: string;
    readonly config?: Record<string, any>;
}
/** Props `AccountStrategy.one` */
export interface AccountStrategyOneProps {
    readonly [AccountType.MOCK]?: AccountConfiguration;
    readonly [AccountType.SHARED]: AccountConfiguration;
}
/** Props `AccountStrategy.two` */
export interface AccountStrategyTwoProps {
    readonly [AccountType.MOCK]?: AccountConfiguration;
    readonly [AccountType.DEV]: AccountConfiguration;
    readonly [AccountType.PROD]: AccountConfiguration;
}
/** Props `AccountStrategy.three` */
export interface AccountStrategyThreeProps {
    readonly [AccountType.MOCK]?: AccountConfiguration;
    readonly [AccountType.DEV]: AccountConfiguration;
    readonly [AccountType.PREPROD]: AccountConfiguration;
    readonly [AccountType.PROD]: AccountConfiguration;
}
export declare const emptyMockAccountProps: AccountConfiguration;
/**
 * Use static methods of `AccountStrategy` abstract class to define your account strategy.
 * Available strategies are:
 * - One Account: `shared`
 * - Two Accounts: `dev`+`prod` – _recommended_
 * - Three Accounts: `dev`+`preprod`+`prod`
 */
export declare abstract class AccountStrategy {
    /**
     * Enables single account strategy.
     *
     * 1. `shared` account with environments:
     *    - development
     *    - feature/*
     *    - test
     *    - qaN
     *    - staging
     *    - preproduction
     *    - production
     *
     * @example
     * AccountStrategy.one({
     *   shared: {
     *     id: '111111111111',
     *   },
     * }),
     */
    static one(props: AccountStrategyOneProps): Record<string, Account>;
    /**
     * Enables dual account strategy.
     *
     * 1. `dev` account with environments:
     *    - development
     *    - feature/*
     *    - test
     *    - qaN
     *    - staging
     * 2. `prod` account with environments:
     *    - preproduction
     *    - production
     *
     * @example
     * AccountStrategy.two({
     *   dev: {
     *     id: '111111111111',
     *   },
     *   prod: {
     *     id: '222222222222',
     *   },
     * }),
     */
    static two(props: AccountStrategyTwoProps): Record<string, Account>;
    /**
     * Enables triple account strategy.
     *
     * 1. `dev` account with environments:
     *    - development
     *    - feature/*
     *    - test
     *    - staging
     * 2. `preprod` account with environments:
     *    - qaN
     *    - preproduction
     * 3. `prod` account with environments:
     *    - production
     *
     * @example
     * AccountStrategy.three({
     *   dev: {
     *     id: '111111111111',
     *   },
     *   preprod: {
     *     id: '222222222222',
     *   },
     *   prod: {
     *     id: '333333333333',
     *   },
     * }),
     */
    static three(props: AccountStrategyThreeProps): Record<string, Account>;
}
