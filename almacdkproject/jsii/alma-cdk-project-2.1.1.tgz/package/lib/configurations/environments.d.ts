declare class EnvRegExp {
    private regexp;
    constructor(base: string);
    test(value: string): boolean;
}
/**
 * Availalbe Enviroment Categories.
 *
 * Categories are useful grouping to make distinction between `stable`
 * environments (`staging` & `production`) from `feature` or `verification`
 * environments (such as `test` or `preproduction`).
 */
export declare enum EnvironmentCategory {
    MOCK = "mock",
    DEVELOPMENT = "development",
    FEATURE = "feature",
    VERIFICATION = "verification",
    STABLE = "stable"
}
/**
 * Available Environment Labels.
 *
 * Labels are useful since Environment Name can be complex,
 * such as `feature/foo-bar` or `qa3`,
 * but we need to be able to “label” all `feature/*` and `qaN` environments
 * as either `feature` or `qa`.
 */
export declare enum EnvironmentLabel {
    MOCK = "mock[0-9]",
    DEVELOPMENT = "development",
    FEATURE = "feature/[/a-zA-z0-9-]+",
    TEST = "test",// replaces "prestaging"
    STAGING = "staging",
    QA = "qa[0-9]",
    PREPRODUCTION = "preproduction",
    PRODUCTION = "production"
}
/**
 * Map Environment Type to Environment Category.
 * I.e. `staging` and `production` are considered being `stable` environments.
 */
export declare const labelToCategory: Record<EnvironmentLabel, EnvironmentCategory>;
export declare const ENV_REGEXP_MOCK: EnvRegExp;
export declare const ENV_REGEXP_FEATURE: EnvRegExp;
export declare const ENV_REGEXP_QA: EnvRegExp;
/**
 * TODO document
 */
export declare function getLabelByName(name: string): EnvironmentLabel;
/**
 * TODO document
 */
export declare function getCategoryByLabel(label: EnvironmentLabel): EnvironmentCategory;
export {};
